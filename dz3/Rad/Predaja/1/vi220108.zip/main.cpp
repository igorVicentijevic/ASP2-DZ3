#include <iostream>
#include <string>

#include "AddressFunction.h"
#include "LinearAddressing.h"
#include "HashTable.h"
#include "AdaptiveHashTable.h"

#include "Meni.h"


using namespace  std;

extern HashTable * hTable = nullptr;


void DodavanjeIPretragaVecegBrojaKljuceva(HashTable& hTable, long long * keysToAdd, long long n, long long numOfRandKeys)
{
    long long minKey = INFINITY;
    long long maxKey = 0;

    for (int i = 0; i < n; ++i) {
        long long keyToAdd = keysToAdd[i];
        hTable.insertKey(keyToAdd,"");

        if(keyToAdd > maxKey) maxKey = keyToAdd;
        if(keyToAdd < minKey) minKey = keyToAdd;
    }

    for (int i = 0; i < numOfRandKeys; ++i) {

        long long randKey = minKey + (double ) rand()/RAND_MAX * (maxKey-minKey);

        cout<<randKey<< " :: "<< (hTable.findKey(randKey) == nullptr ? "Nije nadjen" :"Nadjen")<<endl;
        cout<<'\t'<<"Prosek uspesna pretraga: "<<hTable.avgAccessSuccess()<<endl;
        cout<<'\t'<<"Prosek neuspesna pretraga: "<<hTable.avgAccesUnsuccess()<<endl;
    }
}



int main() {

    srand(24141);

    AddressFunction *a;
    a = new LinearAddressing(2);

    //opseg vrednosti kljuceva

    long long low = 1;
    long long high = 1000;

    //Unosenje kljuceva u tabelu


    long long keysToAdd[] = {5,24,19,233,6,8,18};
    long long n = 7;


    cout<<"Da li zelite da koristite adaptivnu hash tabelu?: (y,n)"<<endl;
    char c;

    cin>>c;
    if(c == 'y')
        hTable = new AdaptiveHashTable(9,a);
    else
        hTable = new HashTable(9,a);
    //HashTable hTable(9,a);

    DodavanjeIPretragaVecegBrojaKljuceva(*hTable, keysToAdd, n, 100000);
    cout<<"Ispisivanje tabele:"<<endl<<*hTable;

    Meni();


    return 0;
}
