//
// Created by Igor on 22.12.23..
//

#ifndef RAD_MENI_H
#define RAD_MENI_H

void IspisiMeni();
void Opcija1();
void Opcija2();
void Opcija3();
void Opcija4();
void Opcija5();
void Opcija6();
void Opcija7();
void Opcija8();
void Opcija9();
void Opcija10();
void Opcija11();
void Meni();

#endif //RAD_MENI_H




